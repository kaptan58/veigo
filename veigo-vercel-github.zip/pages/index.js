import React from "react";

export default function Home() {
  return (
    <main style={{
      fontFamily: "Arial, sans-serif",
      padding: "20px",
      backgroundColor: "#000",
      color: "#FFD700",
      minHeight: "100vh",
      display: "flex",
      flexDirection: "column",
      alignItems: "center"
    }}>
      <h1>VEIGO - Web Demo</h1>
      <p>Mobil uygulama görünümüne sahip web sürüm.</p>
    </main>
  );
}
