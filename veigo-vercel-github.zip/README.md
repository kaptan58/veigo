# VEIGO Web Demo

Bu proje, mobil uygulama görünümüne sahip bir Next.js demo sürümüdür.
Vercel üzerinden yayına alınmaya hazırdır.
